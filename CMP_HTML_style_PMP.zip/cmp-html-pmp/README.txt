CMP (Compétences Mentales de Performances) — Style PMP
- 60 questions affichées à la suite, sans noms de catégories ni indice (inversé).
- Calcul des scores, radar 10 branches, export CSV/JSON.
Fichiers :
- CMP_academie_performances.html
- index.html (redirection vers la page principale)
- assets/bandeau.jpg (modifiable)
